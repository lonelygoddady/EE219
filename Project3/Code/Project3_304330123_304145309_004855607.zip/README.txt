***********Project 3 README file***********

help_functions.py - utility functions
pro_1.py, pro_2.py ... - code for each project problems
main.py - main function of this project 

To run this project, please compile main.py:
$python main.py 