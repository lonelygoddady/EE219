import help_functions


def part_1():
    twenty_train, X_tfidf, X_counts, count_vect = help_functions.data_load()
