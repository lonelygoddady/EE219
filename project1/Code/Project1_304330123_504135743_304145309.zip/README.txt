EE 219
/************Team Member************/
Boyang Cai	304330123
Manni Chen	304145309
Zhuoqi Li	004855607

/************Dependencies************/

pandas
numpy
scipy
matplotlib
sklearn
math
os

/************How to run************/
       
python Project1_main.py 


/**************Note**************/
Execution time for the project can be upto 20 mins due to massive data on Neural Network